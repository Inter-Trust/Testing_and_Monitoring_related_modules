
/*
 you need to npm install express before start using this code
*/

var express = require('express');
var http = require('http');
var app = express();

app.use(express.logger('dev'));
app.use(express.bodyParser());

app.post('/', function(req, res){
 //Simply printout the content of the body and return
 var b = new Buffer(req.body.Event, 'base64')
 console.log(b.toString());
 res.send('Yes you can');
});

app.listen(4567);
console.log('Server running at localhost:4567/');
