package unittest;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;


import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import sl.aspects.AttributeGlobal;
import sl.aspects.CountGlobal;
import sl.aspects.MethodGlobal;
import sl.aspects.PingGlobal;
import sl.tools.AttributeStore;
import sl.tools.Counter;
import sl.tools.Injector;
import sl.tools.LogBuffer;
import sl.tools.Log;

import data.A1;
import data.A2;
import data.A3;
import data.A4;
import data.A5;
import data.A6;
import data.A7;
import data.A8;


public class AnnotationTest {
	static LogBuffer log;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		log = Log.log_to_buffer();
	}

	@Before
	public void setUp() throws Exception { 
		log.clear();
		Counter.clear();
		}
	
	@After
	public void tearDown() throws Exception {
		enable_globals(false);
		Log.i("Test End"); 
	}
	
	private void assertLog(int line, String attrs) {
		String[] a = attrs.split(",");
		try {
			AttributeStore logline = log.Entry(line);
			for(String i: a) logline = logline.Has(i.trim());
		} catch(Exception e) {
			System.out.println(e);
			fail();
		}
	}
	
	private void non_annotated_code() {
		A4 b = new A4();
		b.ping();
		b.outer();
		b.change_variables();
	}

	@Test
	public void monitor_method_attribute() throws Exception {
		A1 a = new A1();
		try { 
			a.outer(); // should produce exit_status:fail
		} catch(Exception e) {}
		a.ping(); // 
		a.params("hello", 12);
		a.change_variables(); // not monitored, should generate no log
		non_annotated_code(); // should produce no logs
		int i = 0;
		assertLog(i++, "msg:Method Enter, name:data.A1.outer");
		assertLog(i++, "msg:Method Leave, name:data.A1.outer");
		assertLog(i++, "msg:Ping, name:data.A1.ping");
		assertNotNull(log.Entry(i++).Has("msg:Method Enter").Has("parameters:[hello, 12]"));
		assertLog(i++, "msg:Method Leave, name:data.A1.params, return_value:12");		
		assertLog(i++, "msg:Attribute changed, value:1, name:data.A1.variableA");
		assertEquals(log.size(), 6);
	}
	
	@Test
	public void taint() throws Exception {
		A2 a = new A2();
		a.outer();
		a.taint();
		non_annotated_code();
		assertLog(0, "msg:Method Enter, name:data.A2.taint");
		assertLog(1, "msg:Method Enter, name:data.A2.inner");
		assertLog(2, "msg:Method Leave, name:data.A2.inner");
		assertLog(3, "msg:Method Leave, name:data.A2.taint");
		assertEquals(log.size(), 4);
	}
	
	@Test
	public void monitor_class() throws Exception {
		A3 a = new A3();
		a.ping();
		a.outer();
		a.change_variables();
		non_annotated_code();
		
		int i = 0;
		assertLog(i++, "msg:Method Enter, name:data.A3.ping");
		assertLog(i++, "msg:Method Leave, exit_status:success");
		assertLog(i++, "msg:Method Enter, name:data.A3.outer");
		assertLog(i++, "msg:Method Leave, exit_status:success, name:data.A3.outer");
		assertLog(i++, "msg:Method Enter, name:data.A3.change_variables");
		assertLog(i++, "msg:Attribute changed, value:1, name:data.A3.variableA");
		assertLog(i++, "msg:Method Leave, name:data.A3.change_variables");
		assertEquals(log.size(), i);
	}
	
	@Test
	public void count() throws Exception {
		//Log.enable_stdout(false);
		List<A5> as = new ArrayList<A5>();
		List<A6> a6s = new ArrayList<A6>();
		for(int i = 0; i<10; i++) as.add(new A5());
		for(int i = 0; i<5; i++) a6s.add(new A6());
		as.get(0).ping();
		assertLog(0, "count(data.A5):10, count(data.A6):5, tracked_objects:15");
	}
	
	@Test
	public void inject() throws Exception {
		@SuppressWarnings("unused")
		A7 a = new A7();
		Injector ca = Injector.singleton();
		ca.resetAll();
		assertLog(1, "msg:A7 reset");
	}
	
	@Test 
	public void global() throws Exception {
		enable_globals(true);
		A8 a8 = new A8();
		a8.ping();
		a8.outer();
		a8.change_variables();
		assertLog(0, "msg:Ping, name:data.A8.ping");
		assertLog(2, "msg:Method Leave, name:data.A8.ping");
		assertLog(4, "msg:Method Enter, name:data.A8.change_variables");
		assertLog(8, "msg:Attribute changed, name:data.A8.variableB");
		assertLog(9, "tracked_objects:1");
		assertEquals(log.size(), 10);
		enable_globals(false);
	}

	private void enable_globals(boolean b) {
		AttributeGlobal.enable(b);
		CountGlobal.enable(b);
		MethodGlobal.enable(b);
		PingGlobal.enable(b);
	}
}
