package data;
import sl.Inject;
import sl.tools.Log;

@Inject(reset="reset_me_please")
public class A7 {
	public void reset_me_please() { Log.i("A7 reset");}
}
