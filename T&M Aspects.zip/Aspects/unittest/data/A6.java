package data;
import sl.*;

@Count
public class A6 {
	@Ping
	public void ping() {};
}
