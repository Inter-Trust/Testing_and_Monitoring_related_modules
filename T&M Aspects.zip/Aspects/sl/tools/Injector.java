package sl.tools;

import java.lang.annotation.Annotation;
import java.util.WeakHashMap;
import sl.Inject;

public class Injector {
	WeakHashMap<Object, String> objects = new WeakHashMap<Object, String>();
	private static Injector center = new Injector();
	
	private Injector(){};
	
	public static Injector singleton() {
		return center;
	}
	
	public void add_reset_function(Object obj) {
		String method = get_reset_method(obj);
		if(method != null) objects.put(obj, method);
		else Log.i(String.format("Error, class %s has no valid reset function!", obj.getClass().getName()));
	}
	
	private static String get_reset_method(Object obj) {
		Annotation[] ann = obj.getClass().getAnnotations();
		for(Annotation a: ann) {
			if(a instanceof Inject) {
				Inject o = (Inject) a;
				return o.reset();
			}			
		}
		return null; //Annotation not found
	}
	
	public void del(Object obj) {
		objects.remove(obj);
	}
	
	public void resetAll() {
		for(Object o: objects.keySet()) {
			call_method(o, objects.get(o));
		}
	}
	
	static void call_method(Object obj, String method_name) {
		try {
			//Security, NoSuchMethod
			java.lang.reflect.Method method = obj.getClass().getMethod(method_name);
			// IllegalArgument, IllegalAccess, InvocationTarget
			if(method != null) method.invoke(obj);
			else {
				Log.i("Error, "+method_name+" not found ");
			}
		} catch (Exception e){
			Log.i("Error " + e);
		}
	}
}
