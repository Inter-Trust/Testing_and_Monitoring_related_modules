package sl.tools;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.reflect.SourceLocation;

import com.google.gson.Gson;

public class Log {
	static LogBuffer log_buffer;
	static final String ini_file = "notify.json";
	static RemoteLogger remote = connect_remote_logger();
	static boolean stdout_enabled = log_mode_from_json(); 
	
	// Java has no default value parameters :-(
	public static void i(String msg) { i(msg, null); }
	public static void i(String s, JoinPoint jp) { i(s, jp, new AttributeStore());	}
	public static void i(String msg, JoinPoint jp, AttributeStore as) {
		if(jp != null) add_info(as, jp);
		String rest = as.toString();
		if(stdout_enabled) {
			if(!rest.equals("")) System.out.println(msg + " -- " + rest);
			else System.out.println(msg);
		}
		if(log_buffer != null) log_buffer.log(msg, as);
		if(remote != null) {
			boolean connection_ok = remote.log(as);
			if(!connection_ok) remote = null; // Drop the remote logger functionality.
			// Otherwise we have a delay penalty on each retry.
		}
	}
	static public class NotifyIni {
		public String remote_logger_url;
		public boolean log_to_stdout;
	}
	
	static NotifyIni read_ini(String path) {
		File f = new File(path);
		boolean ini_found = f.exists() && !f.isDirectory(); 
		if(!ini_found) return null;
		try {
			Reader r = new FileReader(path);
			Gson gson = new Gson();
			NotifyIni notify_ini = gson.fromJson(r, NotifyIni.class);
			return notify_ini;
		} catch (FileNotFoundException e) {
			Log.i("Error reading "+path+" "+e);
		}
		return null;
	}
	
	static private String remote_logger_url(String path) {
		NotifyIni ini = read_ini(path);
		if(ini == null) return null;
		return ini.remote_logger_url;
	}
	
	private static boolean log_mode_from_json() {
		NotifyIni ini = read_ini(ini_file);
		return ini.log_to_stdout;
	}
	
	static public void enable_stdout(boolean enable) { stdout_enabled = enable; }
	
	static private RemoteLogger connect_remote_logger() {
		try {
			String url = remote_logger_url(ini_file);
			if(url!=null) {
				Log.i("Connecting to remote logger at "+url);
				return new RemoteLogger(url);
			} 
			Log.i("Could not extract remote logger url from " + ini_file);
		} catch(Exception e) {
			Log.i("RemoteLogger could not be initialized. "+e);
		}
		return null;
	}
	
	public static void log_attribute(String msg, JoinPoint jp) {
		AttributeStore as = new AttributeStore();
		as.push_back("value", get_attribute_value(jp));
		i(msg, jp, as);
	}
	
	public static String get_attribute_value(JoinPoint a) {
		Object[] args = a.getArgs();
		if(args==null || args.length <1) return "";
		return args[0].toString();
	}

	private static void add_info(AttributeStore as, JoinPoint jp) {
		add_source_location(as, jp);
		as.push_back("thread_name", Thread.currentThread().getName());
		as.push_back("thread_count", Thread.activeCount());
		as.push_back("time_stamp", System.currentTimeMillis());
		Counter.log(as);
	}
	
	static void add_source_location(AttributeStore as, JoinPoint jp) {
		Signature sig = jp.getSignature();
		String module = def(sig.getDeclaringTypeName());
		String name = def(sig.getName());
		as.push_back("name", module+"."+name);
		
		SourceLocation so = jp.getSourceLocation();
		String file = def(so.getFileName());
		String line = def(Integer.toString(so.getLine()));
		as.push_back("source", file+":"+line);
	}	
	
	// return default value on null
	static private String def(String s) 		   { return def(s, "");	}
	static private String def(String s, String d ) { return (s==null)?d:s;	}

	static void get_parameters(JoinPoint a, AttributeStore as) {
		Object[] args = a.getArgs();
		if(args == null || args.length == 0) return;
		String params = StringUtils.join(args,", ");
		String buf = String.format("[%s]", params);
		as.push_back("parameters", buf);
	}
	
	static void get_return_value(JoinPoint a, AttributeStore as) {
		Object[] args = a.getArgs();
		if(args == null || args.length == 0) return;
		as.push_back("return_value", args[0]);
	}
	
	public static LogBuffer log_to_buffer() {
		log_buffer = new LogBuffer();
		return log_buffer;
	}
}
