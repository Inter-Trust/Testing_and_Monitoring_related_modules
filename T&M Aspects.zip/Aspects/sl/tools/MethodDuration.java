package sl.tools;


import java.util.Locale;

import org.aspectj.lang.JoinPoint;

public class MethodDuration {
	long start;
	String ex = null;

	public MethodDuration(JoinPoint jp) {
		start = System.nanoTime(); 
		AttributeStore as = new AttributeStore();
		Log.get_parameters(jp, as);
		Log.i("Method Enter", jp, as);
	}
	
	public void set_exception(Exception e) {
		ex = "\""+e.toString()+"\"";
	}
	
	// TODO: Obsolete remove
	public void on_end(JoinPoint jp) {
		long end = System.nanoTime();
		AttributeStore as = new AttributeStore();
		boolean no_ex = ex == null;
		as.push_back("exit_status", no_ex?"success":"exception_thrown");
		if(!no_ex) as.push_back("exception", ex);
		String duration = String.format(Locale.ENGLISH,"%.3f", (end-start)/1000.0);
		as.push_back("duration[\u00b5s]", duration);
		Log.get_parameters(jp, as);
		Log.i("Method Leave", jp, as);
	}

	public void on_end(JoinPoint jp, boolean success, Object return_value) {
		long end = System.nanoTime();
		AttributeStore as = new AttributeStore();
		boolean no_ex = ex == null;
		as.push_back("exit_status", no_ex?"success":"exception_thrown");
		if(!no_ex) as.push_back("exception", ex);
		String duration = String.format(Locale.ENGLISH,"%.3f", (end-start)/1000.0);
		as.push_back("duration[\u00b5s]", duration);
		if(success)
			as.push_back("return_value", return_value);
		Log.i("Method Leave", jp, as);		
	}
}
