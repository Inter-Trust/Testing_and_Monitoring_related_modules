package sl.tools;

import java.util.ArrayList;

import com.montimage.mmt.client.connector.GenericFieldValueHeader;
import com.montimage.mmt.client.connector.MMTFieldValueHeader;

public class AttributeStore {
	ArrayList<Attribute> attributes = new ArrayList<Attribute>();
	boolean fail = false;
	
	public void push_back(String name, Object value) {
		attributes.add(new Attribute(name, value==null?"null":value));
	}
	
	public void push_front(String name, Object value) {
		attributes.add(0, new Attribute(name, value));
	}
	
	public String toString() {
		if(attributes.isEmpty()) return "";
		StringBuffer buf = new StringBuffer();
		Attribute last = attributes.get(attributes.size()-1);
		for(Attribute a: attributes) {
			buf.append(a.name + ":"+a.value);
			if(a != last) buf.append(", ");
		}
		return buf.toString();
	}
	
	static public void add(ArrayList<MMTFieldValueHeader> ar, String key, String value) {
	   ar.add(new GenericFieldValueHeader(key, value));
	}

	public ArrayList<MMTFieldValueHeader> to_remote_log() {
		ArrayList<MMTFieldValueHeader> ar = new ArrayList<>();
		for(Attribute a: attributes) add(ar, a.name, a.value);
		return ar; 
	}

	// unit test support
	public AttributeStore Has(String pair) throws Exception {
		String[] buf = pair.split(":");
		if(buf.length != 2) throw new Exception("name:value expected, not: "+pair);
		Has(buf[0], buf[1]);
		return this;
	}
	
	private AttributeStore Has(String name, String value) throws Exception {
		Attribute a = new Attribute(name, value);
		for(Attribute i: attributes)
			if(i.equals(a)) return this;
		throw new Exception(name+":"+value+" not found");
	}
}
