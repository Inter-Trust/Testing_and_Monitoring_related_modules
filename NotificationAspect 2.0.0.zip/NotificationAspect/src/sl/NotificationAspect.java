package sl;

import sl.tools.Log;

public class NotificationAspect {
	public static void enable_log_to_stdout(Boolean enable) {
		Log.enable_log_stdout(true);
	}
	
	public static void connectMonitoringTool(String url) throws Exception {
		Log.connect_remote(url);
	}
}
